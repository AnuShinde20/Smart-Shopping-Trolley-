// server.js
const express = require('express');
const Razorpay = require('razorpay');
const app = express();
const port = 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Replace with your Razorpay Key ID (no secret required for order creation)
const razorpay = new Razorpay({
  key_id: 'YOUR_RAZORPAY_KEY_ID',  // Replace with your Key ID
  // key_secret: 'YOUR_RAZORPAY_KEY_SECRET'  // Omit the Key Secret since you're not verifying payments
});

// Route to create an order in Razorpay
app.post('/create-order', async (req, res) => {
  const { amount } = req.body;  // Amount to be paid (in smallest unit, e.g., paise for INR)
  
  try {
    // Create an order in Razorpay
    const order = await razorpay.orders.create({
      amount: amount * 100, // Razorpay accepts amount in paise (smallest currency unit)
      currency: 'INR',
      receipt: 'order_rcptid_11',  // Custom receipt ID for tracking orders
      payment_capture: 1  // Auto-capture payment (1)
    });
    
    res.json(order);  // Send order details to frontend
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
