


  // Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyATqXMDqF_81Fn1wp4JzRW2c9qcLR7DQrA",
    authDomain: "trial-eb597.firebaseapp.com",
    databaseURL: "https://trial-eb597-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "trial-eb597",
    storageBucket: "trial-eb597.appspot.com",
    messagingSenderId: "520767115548",
    appId: "1:520767115548:web:feaa074454c6f5d61cead9",
    measurementId: "G-N3M921LFZY"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
  const database = firebase.database();

  // Sign-Up Functionality
  document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fullname = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const password = document.getElementById('password').value;

    try {
      // Create user with Firebase Authentication
      const userCredential = await auth.createUserWithEmailAndPassword(email, password);
      const user = userCredential.user;

      // Store user data in Firebase Realtime Database under "members"
      await database.ref('members/' + user.uid).set({
        name: fullname,
        email: email,
        phone: phone,
        address: address
      });

      alert("Account registered successfully!");
      window.location.href = 'login.html'; // Redirect to login page
    } catch (error) {
      console.error("Error signing up:", error.message);
      alert("Error: " + error.message);  // Alert error
    }
  });

  // Login Functionality
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
      // Log the user in with Firebase Authentication
      const userCredential = await auth.signInWithEmailAndPassword(email, password);
      const user = userCredential.user;

      // Redirect the user to the dashboard or home page
      window.location.href = 'home.html'; // Change to your dashboard page
    } catch (error) {
      console.error("Error logging in:", error.message);
      alert("Invalid login credentials. Please check your email and password.");
    }
  });

  // Redirect if not authenticated (for protected pages)
  auth.onAuthStateChanged((user) => {
    const protectedPages = ['/home.html', '/login.html']; // Add paths of protected pages
    if (!user && protectedPages.includes(window.location.pathname)) {
      window.location.href = '/login.html'; // Redirect to login page if not logged in
    }
  });

