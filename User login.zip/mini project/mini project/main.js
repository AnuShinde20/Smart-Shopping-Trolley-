// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATqXMDqF_81Fn1wp4JzRW2c9qcLR7DQrA",
    authDomain: "trial-eb597.firebaseapp.com",
    databaseURL: "https://trial-eb597-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "trial-eb597",
    storageBucket: "trial-eb597.appspot.com",
    messagingSenderId: "520767115548",
    appId: "1:520767115548:web:feaa074454c6f5d61cead9",
    measurementId: "G-N3M921LFZY"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();

// Monitor user login status
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        console.log("User logged in: ", user.uid);
        loadCartItems();
    } else {
        console.log("No user logged in.");
        alert("Please log in first.");
    }
});

// Clear session storage
sessionStorage.clear();

// Function to dynamically load cart items from Firebase
function loadCartItems() {
    const cartRef = firebase.database().ref('Cart');
    const cartItemsContainer = document.getElementById('cart-items');
    let totalPrice = 0;
    let srNo = 1;

    cartRef.once('value', snapshot => {
        cartItemsContainer.innerHTML = ''; // Clear existing rows

        if (!snapshot.exists()) {
            console.error('Cart is empty or does not exist.');
            alert('No items in the cart.');
            return;
        }

        snapshot.forEach(childSnapshot => {
            const product = childSnapshot.val();

            // Trim spaces from fields
            const name = product.Name ? product.Name.trim() : "Unknown";
            const modelNo = product.Model_no ? product.Model_no.trim() : "N/A";

            // Extract numeric price value
            const priceString = product.Price ? product.Price.trim() : "0";
            const price = parseFloat(priceString.replace(/[^0-9.]/g, "")); // Remove non-numeric characters

            const row = `
                <tr>
                    <td>${srNo++}</td>
                    <td>${name}</td>
                    <td>${modelNo}</td>
                    <td class="item-price">Rs.${price.toFixed(2)}</td>
                </tr>
            `;

            // Add the row to the table
            cartItemsContainer.innerHTML += row;

            // Calculate total price
            totalPrice += price;
        });

        // Update the total price in the UI
        document.getElementById('total-price').innerText = totalPrice.toFixed(2);

        // Attach Razorpay payment handler after total is calculated
        setupRazorpay(totalPrice);
    }).catch(error => {
        console.error('Error loading cart items:', error);
    });
}

// Razorpay integration
function setupRazorpay(total) {
    const options = {
        "key": "rzp_test_oeUzrT6kkoiAV8", // Replace with your Razorpay key
        "amount": total * 100, // Amount in paise
        "currency": "INR",
        "name": "Smart Cart",
        "description": "Total Payment",
        "handler": function (response) {
            const user = firebase.auth().currentUser;
            if (!user) {
                alert("User not logged in. Please log in to complete the payment.");
                return;
            }

            const userId = user.uid;

            // Construct payment data
            const paymentData = {
                TransactionID: response.razorpay_payment_id,
                Amount: total,
                Method: "Razorpay",
                DateTime: new Date().toISOString()
            };

            // Store payment data in Firebase under the user's PaymentHistory
            firebase.database().ref(`userAccounts/${userId}/PaymentHistory`).push(paymentData)
                .then(() => {
                    alert("Payment successful! Payment ID: " + response.razorpay_payment_id);
                })
                .catch(error => {
                    console.error("Error saving payment data:", error);
                    alert("Payment was successful, but we couldn't save the details. Please contact support.");
                });
        },
        "prefill": {
            "name": "Customer Name",
            "email": "customer@example.com",
            "contact": "1234567890"
        },
        "theme": {
            "color": "#F37254"
        }
    };

    const rzp = new Razorpay(options);

    document.getElementById('rzpButton').addEventListener('click', function () {
        rzp.open();
    });
}
// Payment success function (example)
async function onPaymentSuccess() {
    console.log("Payment completed successfully!");

    
}
async function fetchCartDataAndGeneratePDF() {
    try {
        const cartRef = ref(db, "Cart");
        const snapshot = await get(cartRef);

        if (snapshot.exists()) {
            const cartData = [];
            let srNo = 1;

            const data = snapshot.val();
            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    const item = data[key];
                    cartData.push({
                        srNo: srNo++,
                        modelNo: item.Model_no.trim(),
                        name: item.Name.trim(),
                        price: parseFloat(item.Price.trim())
                    });
                }
            }

            generatePDF(cartData);
        } else {
            console.log("No data found in cart.");
        }
    } catch (error) {
        console.error("Error fetching cart data: ", error);
    }
}

// Generate PDF
function generatePDF(cartData) {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("Cart History", 10, 10);

    let y = 30;
    doc.setFontSize(12);
    doc.text("Sr. No", 10, y);
    doc.text("Model No", 30, y);
    doc.text("Name", 80, y);
    doc.text("Price (₹)", 150, y);
    y += 10;

    cartData.forEach((item) => {
        doc.text(item.srNo.toString(), 10, y);
        doc.text(item.modelNo, 30, y);
        doc.text(item.name, 80, y);
        doc.text(`₹${item.price.toFixed(2)}`, 150, y);
        y += 10;
    });

    y += 10;
    doc.setFontSize(14);
    const totalPrice = cartData.reduce((sum, item) => sum + item.price, 0).toFixed(2);
    doc.text(`Total: ₹${totalPrice}`, 10, y);

    doc.save("Cart_History.pdf");
}

// Payment success function
async function onPaymentSuccess() {
    console.log("Payment completed successfully!");
    await fetchCartDataAndGeneratePDF();
}

// Simulate payment success
setTimeout(onPaymentSuccess, 3000);

