// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCGNNFlvkZJXk6H0Zzan-yn7vZqSDEDlog",
    authDomain: "addremovestaff.firebaseapp.com",
    databaseURL: "https://addremovestaff-default-rtdb.firebaseio.com",
    projectId: "addremovestaff",
    storageBucket: "addremovestaff.appspot.com",
    messagingSenderId: "1001135162377",
    appId: "1:1001135162377:web:f30e8773421f634c8264d8",
    measurementId: "G-6NF1DHC9LT"
  };