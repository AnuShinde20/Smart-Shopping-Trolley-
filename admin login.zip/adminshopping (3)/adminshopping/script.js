import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getDatabase, ref, set, onValue, remove } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-database.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-analytics.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBduNFzVgj9qyd_hqIqfIrvHFapSiS2dfo",
    authDomain: "add-product-fc02d.firebaseapp.com",
    databaseURL: "https://add-product-fc02d-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "add-product-fc02d",
    storageBucket: "add-product-fc02d.appspot.com",
    messagingSenderId: "351775453943",
    appId: "1:351775453943:web:66bcb2d48939e1329399f2",
    measurementId: "G-Y7B9H3M64Z"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const database = getDatabase(app);

// Check if on Add/Remove Staff page
if (document.getElementById('staffForm')) {
    // Staff form submission
    document.getElementById('staffForm').addEventListener('submit', function(event) {
        event.preventDefault();

        // Collect staff details from the form
        const staffName = document.getElementById('name').value;
        const staffRole = document.getElementById('role').value;
        const staffJoiningDate = document.getElementById('joiningDate').value;
        const staffMobile = document.getElementById('mobile').value;

        const permissions = [];
        document.querySelectorAll('.permissions input[type="checkbox"]:checked').forEach((checkbox) => {
            permissions.push(checkbox.value);
        });

        // Reference to the staff node in Firebase
        const staffRef = ref(database, 'addremovestaff/' + staffName.replace(/\s+/g, '-').toLowerCase());

        // Save staff data in the database
        set(staffRef, {
            name: staffName,
            role: staffRole,
            joiningDate: staffJoiningDate,
            mobile: staffMobile,
            permissions: permissions
        }).then(() => {
            alert('Staff added successfully!');
            // Reset form after submission
            document.getElementById('staffForm').reset();
            loadStaffData();
        }).catch((error) => {
            console.error('Error adding staff:', error);
            alert('Failed to add staff. Please try again.');
        });
    });

    // Load staff data from Firebase
    function loadStaffData() {
        const staffTableBody = document.querySelector('#staffTable tbody');
        staffTableBody.innerHTML = ''; // Clear table content

        const staffRef = ref(database, 'addremovestaff');

        // Retrieve data from Firebase and populate table
        onValue(staffRef, (snapshot) => {
            const staffData = snapshot.val();
            if (staffData) {
                Object.keys(staffData).forEach(staffKey => {
                    const staff = staffData[staffKey];
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${staff.name}</td>
                        <td>${staff.role}</td>
                        <td>${staff.joiningDate}</td>
                        <td>${staff.mobile}</td>
                        <td>${staff.permissions.join(', ')}</td>
                        <td><button class="remove-btn" data-staff="${staffKey}">Remove</button></td>
                    `;
                    staffTableBody.appendChild(row);
                });

                // Add event listener for remove buttons
                document.querySelectorAll('.remove-btn').forEach(button => {
                    button.addEventListener('click', removeStaff);
                });
            }
        });
    }

    // Remove staff from Firebase
    function removeStaff(event) {
        const staffKey = event.target.getAttribute('data-staff');
        const staffRef = ref(database, 'addremovestaff/' + staffKey);

        // Remove staff data from the database
        remove(staffRef)
        .then(() => {
            alert('Staff removed successfully!');
            loadStaffData();
        })
        .catch((error) => {
            console.error('Error removing staff:', error);
            alert('Failed to remove staff. Please try again.');
        });
    }

    // Initial load of staff data when page loads
    loadStaffData();
}

///////////////////////

const invoices = [
    { id: 'INV001', status: 'Paid', amount: 150.00, dueDate: '2023-09-01' },
    { id: 'INV002', status: 'Pending', amount: 250.00, dueDate: '2023-09-15' },
    { id: 'INV003', status: 'Overdue', amount: 300.00, dueDate: '2023-08-20' }
];

// Handle invoice tracking form submission
document.getElementById('invoiceForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const invoiceId = document.getElementById('invoiceId').value;
    const invoice = invoices.find(inv => inv.id === invoiceId);
    const statusMessage = document.getElementById('invoiceStatus');
    const detailsContent = document.getElementById('detailsContent');
    const invoiceDetails = document.getElementById('invoiceDetails');

    if (invoice) {
        // Display invoice status
        statusMessage.innerText = `Status for Invoice ID ${invoiceId}: ${invoice.status}`;
        detailsContent.innerHTML = `Amount: $${invoice.amount.toFixed(2)}<br>Due Date: ${invoice.dueDate}`;
        invoiceDetails.style.display = 'block';

        // Save invoice details to Firebase
        saveInvoiceToFirebase(invoice);
    } else {
        statusMessage.innerText = `Invoice ID ${invoiceId} not found.`;
        invoiceDetails.style.display = 'none';
    }
    this.reset(); // Reset the form
});

// Function to save invoice details to Firebase
function saveInvoiceToFirebase(invoice) {
    const invoiceRef = database.ref('invoices/' + invoice.id);
    invoiceRef.set(invoice, (error) => {
        if (error) {
            console.error('Error saving invoice to Firebase:', error);
        } else {
            console.log('Invoice saved to Firebase successfully:', invoice);
        }
    });
}
